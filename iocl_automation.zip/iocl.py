import os
import re
import time
import json
import random
import platform
import openpyxl
from datetime import datetime
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
import pyautogui
from playwright.sync_api import sync_playwright

# Setup directories relative to script
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
SCREENSHOTS_DIR = os.path.join(SCRIPT_DIR, "screenshots")
EXCEL_FILE = os.path.join(SCRIPT_DIR, "fuel_prices.xlsx")
URLS_FILE = os.path.join(SCRIPT_DIR, "urls.json")

def clean_fuel_name(class_name):
    # Extracts fuel name from classes like 'fuel-icon icn-petrol', 'fuel-icon icn-diesel', 'fuel-icon icn-xptwo', 'fuel-icon icn-indigreen'
    match = re.search(r"\bicn-(\w+)\b", class_name or "")
    if not match:
        return "Unknown"
    fuel = match.group(1)
    return {"xptwo": "XP95", "indigreen": "XtraGreen"}.get(fuel, fuel.capitalize())

def clean_price(price_str):
    match = re.search(r"([\d\.]+)", price_str or "")
    return float(match.group(1)) if match else None

def save_to_excel(results, file_path):
    # Load existing or create new workbook
    if os.path.exists(file_path):
        wb = openpyxl.load_workbook(file_path)
        ws = wb.active
    else:
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "IOCL_Fuel_Prices"

    # Define headers
    headers = [
        "Date & Time",
        "State",
        "City",
        "Petrol Pump Name",
        "Petrol Price (₹/ltr)",
        "Diesel Price (₹/ltr)",
        "XP95 Price (₹/ltr)",
        "XtraGreen Price (₹/ltr)",
        "CNG Price (₹/kg)",
        "Screenshot Link (Relative)",
        "Screenshot Link (Absolute)",
        "IGL Screenshot (Relative)",
        "IGL Screenshot (Absolute)"
    ]

    # Write headers if sheet is empty
    if ws.max_row == 1 and ws.cell(row=1, column=1).value is None:
        ws.append(headers)

    # Style definitions
    header_fill = PatternFill(start_color="1F497D", end_color="1F497D", fill_type="solid") # Dark Navy Blue
    header_font = Font(name="Segoe UI", size=11, bold=True, color="FFFFFF")
    data_font = Font(name="Segoe UI", size=10)
    hyperlink_font = Font(name="Segoe UI", size=10, color="0563C1", underline="single")
    
    thin_border = Border(
        left=Side(style='thin', color='D3D3D3'),
        right=Side(style='thin', color='D3D3D3'),
        top=Side(style='thin', color='D3D3D3'),
        bottom=Side(style='thin', color='D3D3D3')
    )
    
    center_align = Alignment(horizontal="center", vertical="center")
    left_align = Alignment(horizontal="left", vertical="center")
    right_align = Alignment(horizontal="right", vertical="center")

    # Format header row
    for col_idx in range(1, len(headers) + 1):
        cell = ws.cell(row=1, column=col_idx)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = center_align
        cell.border = thin_border

    # Find starting row to append new data
    start_row = ws.max_row + 1
    if start_row == 2 and ws.cell(row=1, column=1).value is None:
        start_row = 1 # Overwrite if it was empty

    # Append results
    for row_data in results:
        rel_val = row_data.get("Screenshot Link (Relative)", "")
        if rel_val and not rel_val.startswith("ERROR"):
            rel_formula = f'=HYPERLINK("{rel_val}", "Open Relative Link")'
        else:
            rel_formula = rel_val

        abs_val = row_data.get("Screenshot Link (Absolute)", "")
        if abs_val and not abs_val.startswith("ERROR"):
            abs_formula = f'=HYPERLINK("{abs_val}", "Open Absolute Link")'
        else:
            abs_formula = abs_val

        igl_rel = row_data.get("IGL Screenshot (Relative)", "")
        if igl_rel and not igl_rel.startswith("ERROR"):
            igl_rel_formula = f'=HYPERLINK("{igl_rel}", "Open CNG Link")'
        else:
            igl_rel_formula = igl_rel

        igl_abs = row_data.get("IGL Screenshot (Absolute)", "")
        if igl_abs and not igl_abs.startswith("ERROR"):
            igl_abs_formula = f'=HYPERLINK("{igl_abs}", "Open CNG Link")'
        else:
            igl_abs_formula = igl_abs

        ws.append([
            row_data.get("Date & Time"),
            row_data.get("State"),
            row_data.get("City"),
            row_data.get("Petrol Pump Name"),
            row_data.get("Petrol Price (₹/ltr)"),
            row_data.get("Diesel Price (₹/ltr)"),
            row_data.get("XP95 Price (₹/ltr)"),
            row_data.get("XtraGreen Price (₹/ltr)"),
            row_data.get("CNG Price (₹/kg)"),
            rel_formula,
            abs_formula,
            igl_rel_formula,
            igl_abs_formula
        ])

    # Format data rows
    for r_idx in range(start_row, ws.max_row + 1):
        ws.row_dimensions[r_idx].height = 22
        for c_idx in range(1, len(headers) + 1):
            cell = ws.cell(row=r_idx, column=c_idx)
            cell.font = data_font
            cell.border = thin_border

            # Formats and alignment
            if c_idx == 1: # Date & Time
                cell.alignment = center_align
            elif c_idx in [2, 3, 4]: # State, City, Pump Name
                cell.alignment = left_align
            elif c_idx in [5, 6, 7, 8, 9]: # Prices
                cell.alignment = right_align
                if cell.value is not None and isinstance(cell.value, (int, float)):
                    cell.number_format = '₹#,##0.00'
            elif c_idx in [10, 11, 12, 13]: # Hyperlinks
                cell.alignment = center_align
                if cell.value and "HYPERLINK" in str(cell.value):
                    cell.font = hyperlink_font

    # Autofit columns
    for col in ws.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            val_str = str(cell.value or "")
            if "HYPERLINK" in val_str:
                val_str = "Open Absolute Link"
            if len(val_str) > max_len:
                max_len = len(val_str)
        ws.column_dimensions[col_letter].width = max(max_len + 4, 12)

    ws.row_dimensions[1].height = 26
    ws.views.sheetView[0].showGridLines = True
    
    wb.save(file_path)
    print(f"Data successfully saved to: {file_path}")

def main():
    os.makedirs(SCREENSHOTS_DIR, exist_ok=True)
    
    if not os.path.exists(URLS_FILE):
        print(f"Error: configuration file '{URLS_FILE}' not found.")
        return

    try:
        with open(URLS_FILE, "r") as f:
            targets = json.load(f)
        print(f"Loaded {len(targets)} targets from urls.json")
    except Exception as e:
        print(f"Error loading urls.json: {e}")
        return

    results = []
    
    # Map columns to target fields
    fuel_cols = {
        "Petrol": "Petrol Price (₹/ltr)",
        "Diesel": "Diesel Price (₹/ltr)",
        "XP95": "XP95 Price (₹/ltr)",
        "XtraGreen": "XtraGreen Price (₹/ltr)"
    }

    print("\nStarting IOCL Fuel Price Scraper & Screenshot Automation...")
    print(f"Screenshots will be saved to: {SCREENSHOTS_DIR}")
    print(f"Excel report will be updated at: {EXCEL_FILE}")
    print("Please keep the screen clear and do not move browser windows during execution to allow correct full screen capturing.\n")

    with sync_playwright() as p:
        # Launch headful browser
        browser = p.chromium.launch(
            headless=False,
            args=["--disable-blink-features=AutomationControlled", "--start-maximized"]
        )
        context = browser.new_context(
            no_viewport=True,
            user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
            locale="en-US",
            timezone_id="Asia/Kolkata"
        )

        for idx, target in enumerate(targets):
            state = target.get("state", "Unknown")
            city = target.get("city", "Unknown")
            name = target.get("name", "Unknown")
            url = target.get("url", "")
            
            if not url:
                print(f"[{idx+1}/{len(targets)}] Skipping: missing URL.")
                continue

            # Polite delay between hits
            if idx > 0:
                delay = random.uniform(3.0, 5.0)
                print(f"Waiting {delay:.2f}s before next retail outlet...")
                time.sleep(delay)

            print(f"[{idx+1}/{len(targets)}] Processing: {state} > {city} > {name}...")
            
            now = datetime.now()
            ts_str = now.strftime("%Y-%m-%d %H:%M:%S")
            
            row = {
                "Date & Time": ts_str,
                "State": state,
                "City": city,
                "Petrol Pump Name": name,
                "Petrol Price (₹/ltr)": None,
                "Diesel Price (₹/ltr)": None,
                "XP95 Price (₹/ltr)": None,
                "XtraGreen Price (₹/ltr)": None,
                "CNG Price (₹/kg)": None,
                "Screenshot Link (Relative)": None,
                "Screenshot Link (Absolute)": None,
                "IGL Screenshot (Relative)": None,
                "IGL Screenshot (Absolute)": None
            }

            page = context.new_page()
            page.set_extra_http_headers({
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.9",
                "Connection": "keep-alive"
            })

            success = False
            error_msg = ""
            
            for attempt in range(1, 3):
                try:
                    # Navigate and load DOM
                    page.goto(url, timeout=45000, wait_until="domcontentloaded")
                    page.bring_to_front()
                    try:
                        page.wait_for_load_state("networkidle", timeout=15000)
                    except:
                        pass
                    
                    # Locate fuel price cards
                    cards = page.query_selector_all(".fule-price-card")
                    if not cards:
                        page.wait_for_timeout(2000)
                        cards = page.query_selector_all(".fule-price-card")
                        if not cards:
                            print("  Warning: Fuel price elements not found on the page (they might be missing for this outlet today).")
                    
                    # Extract prices
                    for card in cards:
                        icon = card.query_selector(".fuel-icon")
                        text = card.query_selector(".fuel-text")
                        if icon and text:
                            fname = clean_fuel_name(icon.get_attribute("class"))
                            val = clean_price(text.text_content().strip())
                            if fname in fuel_cols:
                                row[fuel_cols[fname]] = val

                    # Extract actual pump name from white card details if available
                    try:
                        # Find the container under IndianOil details where the bold title sits
                        # Inside index page, the structure has bold pump name under logo: 
                        # In the white card, the bold label is directly below 'IndianOil' logo header
                        card_header_loc = page.locator(".detail-card-head").first
                        if card_header_loc.count() > 0:
                            row["Petrol Pump Name"] = card_header_loc.text_content().strip()
                        else:
                            # Try general heading inside detail block
                            heading_loc = page.locator("//div[contains(@class, 'detail')]//h1 | //div[contains(@class, 'detail')]//h2 | //div[contains(@class, 'detail')]//h3").first
                            if heading_loc.count() > 0:
                                row["Petrol Pump Name"] = heading_loc.text_content().strip()
                    except:
                        pass

                    # Scroll to make fuel prices visible on screenshot
                    try:
                        heading = page.locator("h2.section-heading").first
                        if heading.count() > 0:
                            heading.scroll_into_view_if_needed(timeout=2000)
                            page.evaluate("window.scrollBy(0, -80)")
                        elif len(cards) > 0:
                            page.locator(".fule-price-card").first.scroll_into_view_if_needed(timeout=2000)
                            page.evaluate("window.scrollBy(0, -120)")
                    except:
                        page.evaluate("window.scrollTo(0, 450)")

                    # Settle animation/scroll
                    page.wait_for_timeout(1500)
                    
                    # Capture entire screen using PyAutoGUI to include system date/time
                    clean_state = re.sub(r'[^\w\-]', '_', state)
                    clean_city = re.sub(r'[^\w\-]', '_', city)
                    clean_name = re.sub(r'[^\w\-]', '_', name)
                    scr_filename = f"{clean_state}_{clean_city}_{clean_name}_{now.strftime('%Y%m%d_%H%M%S')}.png"
                    scr_path = os.path.join(SCREENSHOTS_DIR, scr_filename)
                    
                    screenshot = pyautogui.screenshot()
                    screenshot.save(scr_path)
                    
                    # Relative & Absolute paths for Excel hyperlinks
                    row["Screenshot Link (Relative)"] = f"screenshots/{scr_filename}"
                    row["Screenshot Link (Absolute)"] = os.path.abspath(scr_path)
                    print(f"  Successfully scraped prices and saved screen capture: {scr_filename}")
                    print(f"  Prices -> Petrol: ₹{row['Petrol Price (₹/ltr)'] or 0.0:.2f}, Diesel: ₹{row['Diesel Price (₹/ltr)'] or 0.0:.2f}")
                    
                    # If this is Gurugram, scrape IGL CNG price and take IGL screenshot
                    if city == "Gurugram":
                        print("  Detected Gurugram. Navigating to IGL CNG prices page...")
                        try:
                            # Create a temporary page
                            igl_page = context.new_page()
                            igl_page.goto("https://www.iglonline.net/cng-png-prices", timeout=45000, wait_until="domcontentloaded")
                            igl_page.bring_to_front()
                            igl_page.wait_for_selector('xpath=//tr[th[contains(text(), "Gurugram")]]', timeout=15000)
                            
                            # Extract Gurugram CNG price
                            row_loc = igl_page.locator('xpath=//tr[th[contains(text(), "Gurugram")] and td[contains(text(), "per Kg")]]')
                            if row_loc.count() > 0:
                                td_text = row_loc.locator("td").first.text_content().strip()
                                match = re.search(r"(\d+(?:\.\d+)?)", td_text)
                                if match:
                                    row["CNG Price (₹/kg)"] = float(match.group(1))
                                    print(f"  CNG Price parsed -> CNG: ₹{row['CNG Price (₹/kg)']:.2f}")
                            
                            # Scroll and wait a bit
                            try:
                                row_loc.first.scroll_into_view_if_needed(timeout=2000)
                                igl_page.evaluate("window.scrollBy(0, -100)")
                            except:
                                igl_page.evaluate("window.scrollTo(0, 300)")
                            igl_page.wait_for_timeout(1500)
                            
                            # Capture screenshot of IGL page
                            igl_scr_filename = f"IGL_CNG_Gurugram_{now.strftime('%Y%m%d_%H%M%S')}.png"
                            igl_scr_path = os.path.join(SCREENSHOTS_DIR, igl_scr_filename)
                            pyautogui.screenshot().save(igl_scr_path)
                            
                            row["IGL Screenshot (Relative)"] = f"screenshots/{igl_scr_filename}"
                            row["IGL Screenshot (Absolute)"] = os.path.abspath(igl_scr_path)
                            print(f"  Successfully captured IGL screen: {igl_scr_filename}")
                            igl_page.close()
                        except Exception as igl_err:
                            print(f"  Warning: Failed to scrape IGL prices or take screenshot ({igl_err})")
                            try:
                                igl_page.close()
                            except:
                                pass
                    
                    success = True
                    break
                except Exception as e:
                    error_msg = str(e)
                    print(f"  Attempt {attempt} failed: {error_msg}")
                    time.sleep(2)
            
            if not success:
                print(f"  ERROR: Could not process {name} ({error_msg})")
                try:
                    scr_filename = f"FAIL_{re.sub(r'[^\w\-]', '_', city)}_{now.strftime('%Y%m%d_%H%M%S')}.png"
                    scr_path = os.path.join(SCREENSHOTS_DIR, scr_filename)
                    pyautogui.screenshot().save(scr_path)
                    row["Screenshot Link (Relative)"] = f"screenshots/{scr_filename}"
                    row["Screenshot Link (Absolute)"] = os.path.abspath(scr_path)
                except:
                    pass

            page.close()
            results.append(row)
            
        browser.close()

    if results:
        save_to_excel(results, EXCEL_FILE)
        print("\nScraping complete! The Excel file has been updated.")
        
        # Try to open the file automatically for instant user review
        try:
            if platform.system() == "Darwin":
                os.system(f'open "{EXCEL_FILE}"')
            elif platform.system() == "Windows":
                os.startfile(EXCEL_FILE)
        except:
            pass
    else:
        print("\nNo data collected.")

if __name__ == "__main__":
    main()
