import os
import sys
import shutil
import re
import time
import random
import logging
from datetime import datetime
import pandas as pd
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill
from openpyxl.drawing.image import Image as XLImage
from PIL import Image as PILImage

# =========================================================================
# FOLDER STRUCTURE (Windows)
#
#   <SCRIPT_DIR>/
#   ├── Input/
#   │   ├── <your config file>.xlsx  <- left completely untouched by the
#   │   │                               script (never renamed/overwritten)
#   │   └── run_log.txt              <- log file, all events/errors written here
#   └── Output/
#       └── ddmmyyyy/                     <- one folder per calendar day
#           └── ddmmyyyy_hhmmss/          <- one folder per run
#               ├── ddmmyyyy_hhmmss.xlsx  <- the FINAL filled-in workbook,
#               │                            named after this run's timestamp
#               └── *.png                 <- all screenshots for that run
# =========================================================================

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
INPUT_DIR = os.path.join(SCRIPT_DIR, "Input")
OUTPUT_DIR = os.path.join(SCRIPT_DIR, "Output")
LOG_FILE = os.path.join(INPUT_DIR, "run_log.txt")

IMAGES_SRC_DIR = os.path.join(SCRIPT_DIR, "images")
IGL_SRC_FILE = os.path.join(IMAGES_SRC_DIR, "media__1784016697134.png")

# These get set once per run inside main()
RUN_TIMESTAMP = None          # ddmmyyyy_hhmmss
DAY_OUTPUT_DIR = None         # Output/ddmmyyyy
SCREENSHOTS_DIR = None        # Output/ddmmyyyy/ddmmyyyy_hhmmss — screenshots AND workbook both go here
OUTPUT_EXCEL = None           # SCREENSHOTS_DIR/<ddmmyyyy_hhmmss>.xlsx — the final filled workbook
INPUT_CONFIG_PATH = None      # Input/<original file> — validated, never written to

NO_RESPONSE = "No Response"

# Data structure for the 8 target IOCL petrol stations
IOCL_STATIONS = [
    {
        "website": "https://locator.iocl.com/indianoil-petrol-pump-air-view-more-tolaram-omprakash-gidra-petrol-pump-air-view-more-siliguri-195959/Home",
        "state": "West Bengal", "city": "Siliguri", "name": "Tolaram Omprakash Gidra",
    },
    {
        "website": "https://locator.iocl.com/indianoil-city-fuels-petrol-pump-sector16-gurugram-102684/Home",
        "state": "Haryana", "city": "Gurugram", "name": "City Fuels (Sector 16)",
    },
    {
        "website": "https://locator.iocl.com/indianoil-mehsana-filling-station-petrol-pump-mehsana-palanpur-road-mehsana-230582/Home",
        "state": "Gujarat", "city": "Mehsana (Palanpur Rd)", "name": "Mehsana Filling Station",
    },
    {
        "website": "https://locator.iocl.com/indianoil-sri-sai-petroleums-petrol-pump-bangalore-bazaar-bengaluru-199814/Home",
        "state": "Karnataka", "city": "Bengaluru (Bazaar)", "name": "Sri Sai Petroleums",
    },
    {
        "website": "https://locator.iocl.com/indianoil-maruti-petroleum-petrol-pump-bol-sanand-231318/Home",
        "state": "Gujarat", "city": "Sanand", "name": "Maruti Petroleum",
    },
    {
        "website": "https://locator.iocl.com/indianoil-radhe-fuel-station-petrol-pump-rajpur-mehsana-519286/Home",
        "state": "Gujarat", "city": "Rajpur", "name": "Radhe Fuel Station",
    },
    {
        "website": "https://locator.iocl.com/indianoil-rajnayan-service-centre-petrol-pump-khamla-nagpur-207554/Home",
        "state": "Maharashtra", "city": "Nagpur", "name": "Rajnayan Service Centre",
    },
    {
        "website": "https://locator.iocl.com/indianoil-parvathi-super-fuels-petrol-pump-kanchugaranahalli-bengaluru-199873/Home",
        "state": "Karnataka", "city": "Bengaluru (Kanchugaranahalli)", "name": "Parvathi Super Fuels",
    },
]

# IGL CNG target station
IGL_STATIONS = [
    {
        "website": "https://www.iglonline.net/cng-png-prices",
        "state": "Haryana", "city": "Gurugram", "name": "IGL",
    }
]

COLS_IOCL = [
    "Website", "State", "City", "Pump Name", "Date & Time",
    "Petrol Price (₹/ltr)", "Diesel Price (₹/ltr)", "XP95 Price (₹/ltr)", "XtraGreen Price (₹/ltr)",
    "Screenshot Link", "Screenshot Image"
]

COLS_IGL = [
    "Website", "State", "City", "Pump Name", "Date & Time",
    "CNG Price (₹/kg)", "Screenshot Link", "Screenshot Image"
]


# =========================================================================
# LOGGING SETUP
# =========================================================================

def setup_logging():
    """
    Configures logging to write into Input/run_log.txt (appended across runs)
    AND to the console, so you can watch progress live while everything is
    also captured on disk.
    """
    os.makedirs(INPUT_DIR, exist_ok=True)

    logger = logging.getLogger("fuel_scraper")
    logger.setLevel(logging.INFO)
    logger.handlers = []  # avoid duplicate handlers if re-run in same process

    fmt = logging.Formatter("%(asctime)s | %(levelname)-8s | %(message)s", datefmt="%Y-%m-%d %H:%M:%S")

    file_handler = logging.FileHandler(LOG_FILE, mode="a", encoding="utf-8")
    file_handler.setFormatter(fmt)
    logger.addHandler(file_handler)

    # Force UTF-8 on stdout where possible — Windows terminals often default
    # to a non-UTF-8 codepage (e.g. cp1252), which raises UnicodeEncodeError
    # the moment a ₹ symbol is printed. reconfigure() is safe to call even
    # if stdout is already UTF-8; wrapped in try/except for older consoles
    # that don't support reconfigure at all.
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(fmt)
    logger.addHandler(console_handler)

    return logger


log = setup_logging()


# =========================================================================
# INPUT FOLDER VALIDATION
# =========================================================================

def validate_input_folder():
    """
    Ensures Input/ exists and contains EXACTLY ONE .xlsx file.
    - If the folder is empty -> error, tell the user to place config.xlsx there.
    - If more than one .xlsx is present -> error, ambiguous which to use.
    This file is READ-ONLY as far as the script is concerned — it is never
    renamed, moved, or overwritten. It stays exactly as the user left it.
    Returns the absolute path to the file found (for logging purposes only).
    """
    os.makedirs(INPUT_DIR, exist_ok=True)

    xlsx_files = [f for f in os.listdir(INPUT_DIR) if f.lower().endswith(".xlsx") and not f.startswith("~$")]

    if len(xlsx_files) == 0:
        msg = (f"No .xlsx file found in '{INPUT_DIR}'. Please place a single "
               f"config.xlsx file inside the Input folder and re-run.")
        log.error(msg)
        raise FileNotFoundError(msg)

    if len(xlsx_files) > 1:
        msg = (f"Multiple .xlsx files found in '{INPUT_DIR}': {xlsx_files}. "
               f"Only ONE config file is allowed in the Input folder. "
               f"Please remove the extra file(s) and re-run.")
        log.error(msg)
        raise RuntimeError(msg)

    found_path = os.path.join(INPUT_DIR, xlsx_files[0])
    log.info(f"Input validation passed. Found (untouched, left as-is): {found_path}")
    return found_path


# =========================================================================
# OUTPUT FOLDER (per-day / per-run) SETUP
# =========================================================================

def setup_output_folders():
    """
    Creates:
      Output/ddmmyyyy/                 (per calendar day)
      Output/ddmmyyyy/ddmmyyyy_hhmmss/ (per run — screenshots AND the final
                                         workbook both go directly here, no
                                         extra subfolder)
    Returns (day_dir, run_dir, run_timestamp_str)
    """
    now = datetime.now()
    day_str = now.strftime("%d%m%Y")
    run_str = now.strftime("%d%m%Y_%H%M%S")

    day_dir = os.path.join(OUTPUT_DIR, day_str)
    run_dir = os.path.join(day_dir, run_str)

    os.makedirs(run_dir, exist_ok=True)
    log.info(f"Output run folder ready: {run_dir}")

    return day_dir, run_dir, run_str


# =========================================================================
# HELPERS
# =========================================================================

def clean_fuel_name(class_name):
    match = re.search(r"\bicn-(\w+)\b", class_name or "")
    if not match:
        return "Unknown"
    fuel = match.group(1)
    return {"xptwo": "XP95", "indigreen": "XtraGreen"}.get(fuel, fuel.capitalize())


def clean_price(price_str):
    """
    Extracts a float price out of a raw string like '₹101.91' or '101.91 /Ltr'.
    Returns None if nothing numeric could be found (caller then substitutes
    NO_RESPONSE so the failure is visible in the sheet rather than blank).
    """
    if not price_str:
        return None
    match = re.search(r"([\d]+\.?[\d]*)", str(price_str))
    return float(match.group(1)) if match else None


def safe_price_value(value):
    """Converts None -> 'No Response' string for writing into Excel/logs."""
    return value if value is not None else NO_RESPONSE


def format_worksheet(ws, is_igl=False):
    """
    Format headers, columns, widths, row heights, gridlines,
    and embed screenshots dynamically.
    """
    ws._images = []
    ws.sheet_view.showGridLines = True

    num_cols = len(COLS_IGL) if is_igl else len(COLS_IOCL)
    link_col = num_cols - 1
    img_col = num_cols
    price_cols = [6] if is_igl else [6, 7, 8, 9]

    header_fill = PatternFill(start_color="1F497D", end_color="1F497D", fill_type="solid")
    header_font = Font(name="Segoe UI", size=11, bold=True, color="FFFFFF")
    center_align = Alignment(horizontal="center", vertical="center")
    left_align = Alignment(horizontal="left", vertical="center")
    right_align = Alignment(horizontal="right", vertical="center")
    error_font = Font(name="Segoe UI", size=10, color="FF0000", bold=True)

    for col in range(1, num_cols + 1):
        cell = ws.cell(row=1, column=col)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = center_align

    ws.row_dimensions[1].height = 28

    for row in range(2, ws.max_row + 1):
        ws.row_dimensions[row].height = 70

        for col in range(1, num_cols + 1):
            cell = ws.cell(row=row, column=col)

            if col in price_cols:
                cell.alignment = right_align
                if isinstance(cell.value, (int, float)):
                    cell.number_format = '₹#,##0.00'
                    cell.font = Font(name="Segoe UI", size=10)
                elif cell.value == NO_RESPONSE:
                    # Flag missing/undetected prices clearly in red
                    cell.font = error_font
                else:
                    cell.font = Font(name="Segoe UI", size=10)
            elif col in [1, 2, 3, 5, link_col, img_col]:
                cell.alignment = center_align
                cell.font = Font(name="Segoe UI", size=10)
            else:
                cell.alignment = left_align
                cell.font = Font(name="Segoe UI", size=10)

        cell_link = ws.cell(row=row, column=link_col)
        rel_path = cell_link.value

        if rel_path and not str(rel_path).startswith("ERROR") and rel_path != NO_RESPONSE:
            abs_path = os.path.abspath(os.path.join(SCRIPT_DIR, rel_path)) if not os.path.isabs(rel_path) else rel_path
            if os.path.exists(abs_path):
                cell_link.hyperlink = "file://" + abs_path
                cell_link.value = "View Screenshot"
                cell_link.font = Font(name="Segoe UI", size=10, color="0563C1", underline="single")

                thumb_dir = os.path.dirname(abs_path)
                thumb_path = os.path.join(thumb_dir, f"thumb_{os.path.basename(abs_path)}")
                try:
                    with PILImage.open(abs_path) as img:
                        img.thumbnail((110, 75))
                        img.save(thumb_path)

                    xl_img = XLImage(thumb_path)
                    cell_letter = openpyxl.utils.get_column_letter(img_col)
                    ws.add_image(xl_img, f"{cell_letter}{row}")
                    ws.cell(row=row, column=img_col).value = ""
                except Exception as img_err:
                    ws.cell(row=row, column=img_col).value = f"Error: {img_err}"
                    log.warning(f"Could not embed thumbnail for row {row}: {img_err}")
            else:
                cell_link.value = "Missing Screenshot File"
                cell_link.font = error_font
        elif rel_path == NO_RESPONSE:
            cell_link.font = error_font

    from openpyxl.utils import get_column_letter
    for col in ws.columns:
        col_letter = get_column_letter(col[0].column)
        if col[0].column in [link_col, img_col]:
            ws.column_dimensions[col_letter].width = 18
        elif col[0].column == 1:
            ws.column_dimensions[col_letter].width = 25
        elif col[0].column == 5:
            ws.column_dimensions[col_letter].width = 20
        else:
            max_len = max(len(str(cell.value or '')) for cell in col)
            ws.column_dimensions[col_letter].width = max(max_len + 4, 12)


def save_workbook_data(df_iocl, df_igl):
    """
    Saves dataframe to Input/config.xlsx (single source of truth) and
    applies styling.
    """
    for col in COLS_IOCL:
        if col not in df_iocl.columns:
            df_iocl[col] = None
    df_iocl = df_iocl[COLS_IOCL]

    for col in COLS_IGL:
        if col not in df_igl.columns:
            df_igl[col] = None
    df_igl = df_igl[COLS_IGL]

    with pd.ExcelWriter(OUTPUT_EXCEL, engine='openpyxl') as writer:
        df_iocl.to_excel(writer, sheet_name="fuel prices", index=False)
        df_igl.to_excel(writer, sheet_name="igl", index=False)

    wb = openpyxl.load_workbook(OUTPUT_EXCEL)
    format_worksheet(wb["fuel prices"], is_igl=False)
    format_worksheet(wb["igl"], is_igl=True)
    wb.save(OUTPUT_EXCEL)
    log.info(f"Workbook saved: {OUTPUT_EXCEL}")


def _save_cropped_screenshot(page, dest_path, top_y, bottom_y, label):
    """
    Takes a full-page screenshot to a temporary file, crops it down to the
    [top_y, bottom_y] pixel range (page-document coordinates, not viewport —
    these stay valid regardless of current scroll position), saves the
    cropped result to dest_path, and removes the temporary full-page file.

    top_y/bottom_y are clamped to the actual image bounds so a bad
    coordinate never crashes the run — worst case it just falls back to
    keeping more of the page than intended, rather than erroring out.
    """
    tmp_path = dest_path + ".full.png"
    page.screenshot(path=tmp_path, full_page=True)

    with PILImage.open(tmp_path) as img:
        width, height = img.size
        top = max(0, min(int(top_y), height))
        bottom = max(0, min(int(bottom_y), height))
        if bottom <= top:
            # Fallback: coordinates didn't make sense — keep the whole page
            # rather than produce a blank/inverted crop.
            top, bottom = 0, height
            log.warning(f"{label}: crop bounds were invalid, falling back to full page.")
        cropped = img.crop((0, top, width, bottom))
        cropped.save(dest_path)

    try:
        os.remove(tmp_path)
    except Exception:
        pass


def capture_iocl_price_screenshot(page, filename_prefix, price_element):
    """
    Takes a plain screenshot of exactly what's on screen — NOT a full-page
    screenshot, and NOT cropped afterward with PIL — using the SMALLEST
    possible scroll:

      - If the fuel-price section already fits on screen from the very top
        of the page (scrollY = 0), don't scroll at all. This is what keeps
        the pump-name card in frame together with the prices.
      - Only if the price section's bottom edge would otherwise be cut off
        do we scroll down, and then only by just enough to bring that
        bottom edge fully into view — not centered, not further than
        necessary. This keeps as much of the top of the page (pump name,
        address) visible above it as the viewport allows.
    """
    try:
        try:
            page.bring_to_front()
            page.wait_for_timeout(500)
        except Exception as focus_err:
            log.warning(f"Could not bring page tab to front before screenshot: {focus_err}")

        safe_name = re.sub(r'[\\/*?:"<>|]', "_", filename_prefix)
        filename = f"{safe_name}_{datetime.now().strftime('%H%M%S')}.png"
        dest_path = os.path.join(SCREENSHOTS_DIR, filename)

        if price_element is not None:
            try:
                page.evaluate("window.scrollTo(0, 0)")
                page.wait_for_timeout(300)

                rect = price_element.evaluate(
                    "el => { const r = el.getBoundingClientRect(); "
                    "return {bottom: r.bottom + window.scrollY, viewportHeight: window.innerHeight}; }"
                )
                bottom_y = rect["bottom"]
                viewport_h = rect["viewportHeight"]

                if bottom_y > viewport_h:
                    # Doesn't fit from the top — scroll down by ONLY the
                    # difference, so the price section's bottom just clears
                    # the bottom edge of the viewport (plus a small margin),
                    # keeping as much of the page above it visible as possible.
                    needed_scroll = (bottom_y - viewport_h) + 40
                    page.evaluate(f"window.scrollTo(0, {needed_scroll})")
                    page.wait_for_timeout(500)
                # else: already fully visible from the top — no scroll needed.
            except Exception as e:
                log.warning(f"Could not compute minimal scroll for price section: {e}")

        page.screenshot(path=dest_path, full_page=False)

        rel_path = os.path.relpath(dest_path, SCRIPT_DIR)
        log.info(f"Screenshot captured (minimal scroll, uncropped): {rel_path}")
        return rel_path
    except Exception as e:
        log.error(f"Screenshot capture FAILED for '{filename_prefix}': {e}")
        return NO_RESPONSE


def capture_igl_price_screenshot(page, filename_prefix, row_element):
    """
    Takes a plain screenshot of exactly what's on screen — NOT a full-page
    screenshot, and NOT cropped afterward with PIL — using the SMALLEST
    possible scroll, same approach as the IOCL screenshots:

      - If the Gurugram row already fits on screen from the very top of the
        page (scrollY = 0), don't scroll at all.
      - Only if the row's bottom edge would otherwise be cut off do we
        scroll down, and then only by just enough to bring that bottom
        edge fully into view — keeping as much of the table (including the
        header row for context) visible above it as the viewport allows.
    """
    try:
        try:
            page.bring_to_front()
            page.wait_for_timeout(500)
        except Exception as focus_err:
            log.warning(f"Could not bring page tab to front before screenshot: {focus_err}")

        safe_name = re.sub(r'[\\/*?:"<>|]', "_", filename_prefix)
        filename = f"{safe_name}_{datetime.now().strftime('%H%M%S')}.png"
        dest_path = os.path.join(SCREENSHOTS_DIR, filename)

        if row_element is not None:
            try:
                page.evaluate("window.scrollTo(0, 0)")
                page.wait_for_timeout(300)

                rect = row_element.evaluate(
                    "el => { const r = el.getBoundingClientRect(); "
                    "return {bottom: r.bottom + window.scrollY, viewportHeight: window.innerHeight}; }"
                )
                bottom_y = rect["bottom"]
                viewport_h = rect["viewportHeight"]

                if bottom_y > viewport_h:
                    # Doesn't fit from the top — scroll down by ONLY the
                    # difference, so the Gurugram row's bottom just clears
                    # the bottom edge of the viewport (plus a small margin),
                    # keeping as much of the table (header included) visible
                    # above it as possible.
                    needed_scroll = (bottom_y - viewport_h) + 40
                    page.evaluate(f"window.scrollTo(0, {needed_scroll})")
                    page.wait_for_timeout(500)
                # else: already fully visible from the top — no scroll needed.
            except Exception as e:
                log.warning(f"Could not compute minimal scroll for Gurugram row: {e}")

        page.screenshot(path=dest_path, full_page=False)

        rel_path = os.path.relpath(dest_path, SCRIPT_DIR)
        log.info(f"Screenshot captured (minimal scroll, uncropped): {rel_path}")
        return rel_path
    except Exception as e:
        log.error(f"Screenshot capture FAILED for '{filename_prefix}': {e}")
        return NO_RESPONSE




# =========================================================================
# PRICE EXTRACTION
#
# NOTE: The original script was truncated exactly at the point where it
# called page.goto(...) for the IOCL locator pages, so the actual selectors
# used to read Petrol/Diesel/XP95/XtraGreen off that page were never
# available to reconstruct. The selectors below are a reasonable generic
# starting point based on the icn-<fuel> class naming convention implied by
# clean_fuel_name() in the original file. VERIFY these against the live
# page (right-click a price -> Inspect) and adjust if they don't match —
# every extraction attempt is already wrapped so a wrong selector safely
# degrades to "No Response" instead of crashing the run.
# =========================================================================

def extract_iocl_prices(page, station_name):
    """
    Attempts to read Petrol / Diesel / XP95 / XtraGreen prices off an IOCL
    locator page. Returns (prices_dict, price_element).

    STRATEGY: anchor everything to the literal, human-readable heading text
    "Today's Fuel Price" (the same heading visible in the reference
    screenshot) rather than guessing at CSS class names or an unknown DOM
    depth. This fixes two real problems seen in testing:

      1. Screenshots cutting off far too early. The previous approach
         climbed the DOM from each price icon looking for "any ancestor
         whose text contains a decimal number" — but these pages have OTHER
         decimal numbers near the very top (GPS coordinates, ratings, etc.),
         so it could lock onto the wrong, much-earlier element and crop the
         page way too short.
      2. Price mismatches / wrong elements. These pages have MANY icons
         elsewhere (social links, category icons, ratings) that also match
         "[class*='icn-']". Scoping the search to just inside the fuel-price
         section (instead of the whole page) avoids accidentally grabbing
         one of those.

    price_element returned is the fuel-price SECTION container itself (not
    just one icon) — this is what scrolling/cropping will target, so the
    crop boundary is based on the section's own real height rather than a
    guessed offset from a single icon.

    Any fuel not found on the page (station doesn't sell it, or the
    selector didn't match) comes back as None -> written as 'No Response'.
    """
    prices = {"Petrol": None, "Diesel": None, "XP95": None, "XtraGreen": None}
    price_element = None

    def locate_section():
        """Find the wrapping container of the 'Today's Fuel Price' heading."""
        try:
            heading = page.get_by_text(re.compile(r"today.?s\s+fuel\s+price", re.IGNORECASE)).first
            if heading.count() > 0:
                handle = heading.element_handle()
                if handle:
                    # Climb up a couple of levels from the heading text
                    # itself to the section that wraps the heading AND the
                    # price boxes below it (not just the bare text node).
                    container = handle.evaluate_handle(
                        "el => { "
                        "let node = el; "
                        "for (let i = 0; i < 3 && node.parentElement; i++) { node = node.parentElement; } "
                        "return node; "
                        "}"
                    ).as_element()
                    return container
        except Exception as e:
            log.warning(f"[{station_name}] Could not locate 'Today's Fuel Price' heading: {e}")
        return None

    try:
        page.wait_for_selector("[class*='icn-']", timeout=10000)
    except PlaywrightTimeoutError:
        log.warning(f"[{station_name}] Price container did not load in time — prices will show 'No Response'.")
        return prices, None

    # RETRY LOOP: the price section can exist in the DOM (so the wait above
    # succeeds) before the actual price NUMBERS have finished loading into
    # it — those are often filled in a moment later by a separate async
    # call. Re-scan a few times with a short wait in between rather than
    # giving up on the first blank pass.
    max_attempts = 3
    section_container = None
    for attempt in range(1, max_attempts + 1):
        section_container = locate_section()
        # Fall back to a whole-page icon search only if the heading itself
        # genuinely can't be found (e.g. different wording on some pages) —
        # scoped search is always preferred when the heading is present.
        scope = section_container if section_container is not None else page

        try:
            price_blocks = scope.query_selector_all("[class*='icn-']")
            for block in price_blocks:
                try:
                    class_attr = block.get_attribute("class") or ""
                    fuel = clean_fuel_name(class_attr)
                    if fuel == "Unknown":
                        continue

                    # Price text lives in a nearby container, not on the
                    # icon itself — check the immediate parent first (icon
                    # + price are typically siblings under one small box),
                    # climbing at most 2 levels to stay local and avoid
                    # drifting into unrelated page content.
                    price_text = None
                    container_el = None
                    parent = block.evaluate_handle(
                        "el => { "
                        "let node = el.parentElement; "
                        "for (let i = 0; i < 2 && node; i++) { "
                        "  if (/\\d+\\.\\d+/.test(node.innerText || '')) return node; "
                        "  node = node.parentElement; "
                        "} "
                        "return el.parentElement || el; "
                        "}"
                    )
                    if parent:
                        container_el = parent.as_element()
                        price_text = container_el.inner_text() if container_el else None
                    if not price_text:
                        price_text = block.inner_text()
                        container_el = block

                    value = clean_price(price_text)
                    if value is not None and fuel in prices:
                        prices[fuel] = value
                except Exception as inner_e:
                    log.warning(f"[{station_name}] Could not parse one price block: {inner_e}")
                    continue
        except Exception as e:
            log.warning(f"[{station_name}] Price extraction error (attempt {attempt}/{max_attempts}): {e}")

        if any(v is not None for v in prices.values()):
            if attempt > 1:
                log.info(f"[{station_name}] Prices loaded on retry attempt {attempt}/{max_attempts}.")
            break

        if attempt < max_attempts:
            log.warning(f"[{station_name}] No prices read yet on attempt {attempt}/{max_attempts} — "
                        f"waiting for async price data and retrying...")
            page.wait_for_timeout(2500)

    # The element used for scrolling/cropping is the SECTION container
    # (heading + price boxes together), not a single icon — this is what
    # makes the crop boundary reliable: it's the real bottom of the whole
    # "Today's Fuel Price" block, not a guessed offset from one element.
    if any(v is not None for v in prices.values()):
        price_element = section_container

    for fuel, val in prices.items():
        if val is None:
            log.warning(f"[{station_name}] {fuel} price NOT detected -> 'No Response'.")

    return prices, price_element


def extract_igl_price(page, station_name):
    """
    Attempts to read the CNG price off the IGL prices page.
    Returns (price_or_None, row_element_or_None) — the row element is kept
    so scrolling can target the EXACT row that was read, instead of
    re-searching the table afterward and risking a mismatch.
    """
    try:
        page.wait_for_selector("table, [class*='price']", timeout=10000)
    except PlaywrightTimeoutError:
        log.warning(f"[{station_name}] IGL price table did not load in time — 'No Response'.")
        return None, None

    try:
        # The IGL page lists CNG price in a table; grab the first row that
        # mentions 'Gurugram'/'Gurgaon' and pull the numeric price from it.
        rows = page.query_selector_all("table tr")
        for row in rows:
            text = row.inner_text()
            if re.search(r"gur[ug]gram|gurgaon", text, re.IGNORECASE):
                value = clean_price(text)
                if value is not None:
                    return value, row

        # Fallback: any element carrying a price-like class
        blocks = page.query_selector_all("[class*='price']")
        for b in blocks:
            value = clean_price(b.inner_text())
            if value is not None:
                return value, b

    except Exception as e:
        log.warning(f"[{station_name}] IGL price extraction error: {e}")

    log.warning(f"[{station_name}] CNG price NOT detected -> 'No Response'.")
    return None, None


def scroll_to_iocl_price_section(page, city_name, station_name, price_element=None):
    """
    Scrolls the page (up/down, wherever needed) to bring the section
    containing the fuel price into view, so the screenshot
    actually captures that content instead of whatever happened to be on
    screen at scroll position 0.

    Strategy (in priority order):
      0. If price_element is given (the EXACT element extract_iocl_prices()
         already confirmed contains a real price), scroll straight to that
         same node — no re-searching, so no risk of matching a different,
         possibly-invisible element with the same CSS class.
      1. Otherwise, try a fresh search for a price element (class containing
         'icn-' or 'price').
      2. Fall back to the city name text.
      3. Fall back to a step-scroll sweep down the full page height.
    """
    if price_element is not None:
        try:
            if price_element.is_visible():
                price_element.scroll_into_view_if_needed(timeout=5000)
                page.wait_for_timeout(1000)  # let scroll animation + render settle
                log.info(f"[{station_name}] Scrolled directly to the exact price element that was read.")
                return True
            else:
                log.warning(f"[{station_name}] The exact price element exists but isn't visible — trying fallbacks.")
        except Exception as e:
            log.warning(f"[{station_name}] Could not scroll to the exact price element: {e}")

    try:
        price_el = page.query_selector("[class*='icn-'], [class*='price']")
        if price_el and price_el.is_visible():
            price_el.scroll_into_view_if_needed(timeout=5000)
            page.wait_for_timeout(1000)  # let scroll animation + render settle
            log.info(f"[{station_name}] Scrolled to a price element via fresh search.")
            return True
    except Exception as e:
        log.warning(f"[{station_name}] Could not scroll directly to price element: {e}")

    try:
        city_locator = page.get_by_text(city_name, exact=False).first
        if city_locator.count() > 0:
            city_locator.scroll_into_view_if_needed(timeout=5000)
            page.wait_for_timeout(1000)
            log.info(f"[{station_name}] Scrolled to city name '{city_name}' on page (fallback).")
            return True
    except Exception as e:
        log.warning(f"[{station_name}] Could not scroll to city name: {e}")

    # Final fallback: sweep down the full page height in steps, checking for
    # any visible price element at each stop.
    try:
        page.evaluate("window.scrollTo(0, 0)")
        page.wait_for_timeout(300)
        page_height = page.evaluate("document.body.scrollHeight")
        viewport_height = page.evaluate("window.innerHeight")
        steps = max(1, min(30, int(page_height / max(viewport_height, 1)) + 3))

        for _ in range(steps):
            price_el = page.query_selector("[class*='icn-'], [class*='price']")
            if price_el and price_el.is_visible():
                price_el.scroll_into_view_if_needed(timeout=3000)
                page.wait_for_timeout(700)
                log.info(f"[{station_name}] Scrolled to price section via full-page sweep.")
                return True
            page.mouse.wheel(0, 450)
            page.wait_for_timeout(300)
    except Exception as e:
        log.warning(f"[{station_name}] Full-page scroll sweep failed: {e}")

    log.warning(f"[{station_name}] Could not confirm scroll position for city/price section.")
    return False


def scroll_to_igl_gurugram_row(page, station_name, row_element=None):
    """
    Scrolls the IGL prices table (which lists many cities) up/down until the
    row matching 'Gurugram'/'Gurgaon' is found, then scrolls it into view so
    the screenshot captures that specific city + price row.

    If row_element is given (the EXACT row extract_igl_price() already
    confirmed contains the price), scroll straight to it — no re-search.
    Falls back to a fresh table search only if that's not available.
    """
    if row_element is not None:
        try:
            row_element.scroll_into_view_if_needed(timeout=5000)
            page.wait_for_timeout(1000)
            log.info(f"[{station_name}] Scrolled directly to the exact Gurugram row that was read.")
            return True
        except Exception as e:
            log.warning(f"[{station_name}] Could not scroll to the exact row, trying fresh search: {e}")

    try:
        rows = page.query_selector_all("table tr")
        for row in rows:
            text = row.inner_text()
            if re.search(r"gur[ug]gram|gurgaon", text, re.IGNORECASE):
                row.scroll_into_view_if_needed(timeout=5000)
                page.wait_for_timeout(1000)
                log.info(f"[{station_name}] Scrolled to Gurugram row on IGL page (fresh search).")
                return True
    except Exception as e:
        log.warning(f"[{station_name}] Could not scroll to Gurugram row: {e}")

    log.warning(f"[{station_name}] Gurugram row not found to scroll to — screenshot may not show it.")
    return False


# =========================================================================
# MODE: SCRAPE LIVE PRICES
# =========================================================================

def scrape_live_prices():
    log.info("MODE: Scraping live prices & capturing cropped (name + price only) screenshots...")

    iocl_rows = []
    igl_rows = []

    with sync_playwright() as p:
        log.info("Launching Chromium browser...")
        browser = p.chromium.launch(
            headless=False,
            args=["--disable-blink-features=AutomationControlled", "--start-maximized"]
        )
        context = browser.new_context(
            no_viewport=True,
            user_agent=("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                        "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"),
            locale="en-US",
            timezone_id="Asia/Kolkata"
        )

        # ---- 1. IOCL stations ----
        for idx, s in enumerate(IOCL_STATIONS):
            if idx > 0:
                delay = random.uniform(3.0, 5.5)
                log.info(f"Waiting {delay:.2f}s to avoid rate limiting...")
                time.sleep(delay)

            log.info(f"[{idx + 1}/{len(IOCL_STATIONS)}] Loading IOCL page: {s['city']} ({s['name']})")
            page = context.new_page()
            page.set_extra_http_headers({
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.9"
            })

            now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            prices = {"Petrol": None, "Diesel": None, "XP95": None, "XtraGreen": None}
            rel_screenshot = NO_RESPONSE
            load_succeeded = False

            for attempt in range(1, 4):
                try:
                    page.goto(s["website"], timeout=30000, wait_until="domcontentloaded")
                    page.wait_for_timeout(2000)
                    load_succeeded = True
                    break
                except Exception as e:
                    log.warning(f"[{s['name']}] Attempt {attempt}/3 to load page failed: {e}")
                    time.sleep(2)

            if not load_succeeded:
                log.error(f"[{s['name']}] Page failed to load after 3 attempts. Marking all prices 'No Response'.")
            else:
                price_element = None
                try:
                    prices, price_element = extract_iocl_prices(page, s["name"])
                except Exception as e:
                    log.error(f"[{s['name']}] Unexpected error during price extraction: {e}")

                # Only capture a screenshot if AT LEAST ONE fuel price was
                # actually detected on the page. If nothing was found, skip
                # the screenshot entirely and log it as an error instead —
                # no point saving a screenshot of a page with no prices on it.
                if any(v is not None for v in prices.values()):
                    scroll_to_iocl_price_section(page, s["city"], s["name"], price_element=price_element)
                    rel_screenshot = capture_iocl_price_screenshot(page, f"IOCL_{s['city']}", price_element)
                else:
                    rel_screenshot = NO_RESPONSE
                    log.error(f"[{s['name']}] No fuel prices detected on page — skipping screenshot.")

            page.close()

            iocl_rows.append([
                s["website"], s["state"], s["city"], s["name"], now_str,
                safe_price_value(prices["Petrol"]),
                safe_price_value(prices["Diesel"]),
                safe_price_value(prices["XP95"]),
                safe_price_value(prices["XtraGreen"]),
                rel_screenshot, ""
            ])

        # ---- 2. IGL station(s) ----
        for idx, s in enumerate(IGL_STATIONS):
            delay = random.uniform(2.0, 4.0)
            log.info(f"Waiting {delay:.2f}s before IGL request...")
            time.sleep(delay)

            log.info(f"[{idx + 1}/{len(IGL_STATIONS)}] Loading IGL page: {s['city']} ({s['name']})")
            page = context.new_page()
            page.set_extra_http_headers({
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.9"
            })

            now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            cng_price = None
            rel_screenshot = NO_RESPONSE
            load_succeeded = False

            for attempt in range(1, 4):
                try:
                    page.goto(s["website"], timeout=30000, wait_until="domcontentloaded")
                    page.wait_for_timeout(2000)
                    load_succeeded = True
                    break
                except Exception as e:
                    log.warning(f"[{s['name']}] Attempt {attempt}/3 to load page failed: {e}")
                    time.sleep(2)

            if not load_succeeded:
                log.error(f"[{s['name']}] Page failed to load after 3 attempts. Marking CNG price 'No Response'.")
            else:
                row_element = None
                try:
                    cng_price, row_element = extract_igl_price(page, s["name"])
                except Exception as e:
                    log.error(f"[{s['name']}] Unexpected error during price extraction: {e}")

                # Same rule as IOCL: only screenshot if a price was actually found.
                if cng_price is not None:
                    scroll_to_igl_gurugram_row(page, s["name"], row_element=row_element)
                    rel_screenshot = capture_igl_price_screenshot(page, f"IGL_{s['city']}", row_element)
                else:
                    rel_screenshot = NO_RESPONSE
                    log.error(f"[{s['name']}] No CNG price detected on page — skipping screenshot.")

            page.close()

            igl_rows.append([
                s["website"], s["state"], s["city"], s["name"], now_str,
                safe_price_value(cng_price), rel_screenshot, ""
            ])

        browser.close()

    df_iocl = pd.DataFrame(iocl_rows, columns=COLS_IOCL)
    df_igl = pd.DataFrame(igl_rows, columns=COLS_IGL)

    save_workbook_data(df_iocl, df_igl)
    log.info(f"Run complete. Screenshots in: {SCREENSHOTS_DIR}")
    log.info(f"Workbook: {OUTPUT_EXCEL}\n")


# =========================================================================
# MAIN
# =========================================================================

def main():
    global RUN_TIMESTAMP, DAY_OUTPUT_DIR, SCREENSHOTS_DIR, OUTPUT_EXCEL, INPUT_CONFIG_PATH

    log.info("=" * 70)
    log.info("Fuel Price Scraper — run started")

    try:
        # Validation only — this file is never renamed, moved, or written to.
        INPUT_CONFIG_PATH = validate_input_folder()
    except Exception as e:
        log.error(f"Startup validation failed: {e}")
        sys.exit(1)

    DAY_OUTPUT_DIR, SCREENSHOTS_DIR, RUN_TIMESTAMP = setup_output_folders()
    # Final workbook is named after the run timestamp itself and saved
    # directly in the run folder, alongside that run's screenshots —
    # e.g. Output/28072026/28072026_143205/28072026_143205.xlsx
    OUTPUT_EXCEL = os.path.join(SCREENSHOTS_DIR, f"{RUN_TIMESTAMP}.xlsx")

    try:
        scrape_live_prices()
    except Exception as e:
        log.error(f"Fatal error during scraping run: {e}", exc_info=True)
        sys.exit(1)

    log.info("Run finished successfully.")
    log.info("=" * 70)


if __name__ == "__main__":
    main()
