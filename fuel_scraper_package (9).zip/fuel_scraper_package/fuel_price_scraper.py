import os
import sys
import shutil
import re
import time
import random
import logging
from datetime import datetime
import pandas as pd
import pyautogui
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill
from openpyxl.drawing.image import Image as XLImage
from PIL import Image as PILImage

# Optional: used to force the actual OS window (not just the browser tab) to
# the front before every screenshot. page.bring_to_front() only switches the
# active TAB inside the browser — it does not raise the browser's OS window
# above your terminal/IDE/other apps. Without this, PyAutoGUI can end up
# screenshotting whatever window happens to have OS-level focus instead of
# the browser, which produces exactly the "screenshots show the wrong thing"
# symptom. Install with: pip install pygetwindow
try:
    import pygetwindow as gw
    PYGETWINDOW_AVAILABLE = True
except ImportError:
    PYGETWINDOW_AVAILABLE = False

# =========================================================================
# FOLDER STRUCTURE (Windows)
#
#   <SCRIPT_DIR>/
#   ├── Input/
#   │   ├── <your config file>.xlsx  <- left completely untouched by the
#   │   │                               script (never renamed/overwritten)
#   │   └── run_log.txt              <- log file, all events/errors written here
#   └── Output/
#       └── ddmmyyyy/                     <- one folder per calendar day
#           └── ddmmyyyy_hhmmss/          <- one folder per run
#               ├── ddmmyyyy_hhmmss.xlsx  <- the FINAL filled-in workbook,
#               │                            named after this run's timestamp
#               └── *.png                 <- all screenshots for that run
# =========================================================================

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
INPUT_DIR = os.path.join(SCRIPT_DIR, "Input")
OUTPUT_DIR = os.path.join(SCRIPT_DIR, "Output")
LOG_FILE = os.path.join(INPUT_DIR, "run_log.txt")

IMAGES_SRC_DIR = os.path.join(SCRIPT_DIR, "images")
IGL_SRC_FILE = os.path.join(IMAGES_SRC_DIR, "media__1784016697134.png")

# PyAutoGUI screenshot folder (kept for compatibility; actual screenshots
# for the run are also copied into the dated Output subfolder).
# Uses the user's home directory rather than a fixed C:\rpa path so it never
# hits a Windows permission error writing to the root of C:\.
PYAUTOGUI_SAVE_DIR = os.path.join(os.path.expanduser('~'), 'rpa')

# These get set once per run inside main()
RUN_TIMESTAMP = None          # ddmmyyyy_hhmmss
DAY_OUTPUT_DIR = None         # Output/ddmmyyyy
SCREENSHOTS_DIR = None        # Output/ddmmyyyy/ddmmyyyy_hhmmss — screenshots AND workbook both go here
OUTPUT_EXCEL = None           # SCREENSHOTS_DIR/<ddmmyyyy_hhmmss>.xlsx — the final filled workbook
INPUT_CONFIG_PATH = None      # Input/<original file> — validated, never written to

NO_RESPONSE = "No Response"

# Data structure for the 8 target IOCL petrol stations
IOCL_STATIONS = [
    {
        "website": "https://locator.iocl.com/indianoil-petrol-pump-air-view-more-tolaram-omprakash-gidra-petrol-pump-air-view-more-siliguri-195959/Home",
        "state": "West Bengal", "city": "Siliguri", "name": "Tolaram Omprakash Gidra",
    },
    {
        "website": "https://locator.iocl.com/indianoil-city-fuels-petrol-pump-sector16-gurugram-102684/Home",
        "state": "Haryana", "city": "Gurugram", "name": "City Fuels (Sector 16)",
    },
    {
        "website": "https://locator.iocl.com/indianoil-mehsana-filling-station-petrol-pump-mehsana-palanpur-road-mehsana-230582/Home",
        "state": "Gujarat", "city": "Mehsana (Palanpur Rd)", "name": "Mehsana Filling Station",
    },
    {
        "website": "https://locator.iocl.com/indianoil-sri-sai-petroleums-petrol-pump-bangalore-bazaar-bengaluru-199814/Home",
        "state": "Karnataka", "city": "Bengaluru (Bazaar)", "name": "Sri Sai Petroleums",
    },
    {
        "website": "https://locator.iocl.com/indianoil-maruti-petroleum-petrol-pump-bol-sanand-231318/Home",
        "state": "Gujarat", "city": "Sanand", "name": "Maruti Petroleum",
    },
    {
        "website": "https://locator.iocl.com/indianoil-radhe-fuel-station-petrol-pump-rajpur-mehsana-519286/Home",
        "state": "Gujarat", "city": "Rajpur", "name": "Radhe Fuel Station",
    },
    {
        "website": "https://locator.iocl.com/indianoil-rajnayan-service-centre-petrol-pump-khamla-nagpur-207554/Home",
        "state": "Maharashtra", "city": "Nagpur", "name": "Rajnayan Service Centre",
    },
    {
        "website": "https://locator.iocl.com/indianoil-parvathi-super-fuels-petrol-pump-kanchugaranahalli-bengaluru-199873/Home",
        "state": "Karnataka", "city": "Bengaluru (Kanchugaranahalli)", "name": "Parvathi Super Fuels",
    },
]

# IGL CNG target station
IGL_STATIONS = [
    {
        "website": "https://www.iglonline.net/cng-png-prices",
        "state": "Haryana", "city": "Gurugram", "name": "IGL",
    }
]

COLS_IOCL = [
    "Website", "State", "City", "Pump Name", "Date & Time",
    "Petrol Price (₹/ltr)", "Diesel Price (₹/ltr)", "XP95 Price (₹/ltr)", "XtraGreen Price (₹/ltr)",
    "Screenshot Link", "Screenshot Image"
]

COLS_IGL = [
    "Website", "State", "City", "Pump Name", "Date & Time",
    "CNG Price (₹/kg)", "Screenshot Link", "Screenshot Image"
]


# =========================================================================
# LOGGING SETUP
# =========================================================================

def setup_logging():
    """
    Configures logging to write into Input/run_log.txt (appended across runs)
    AND to the console, so you can watch progress live while everything is
    also captured on disk.
    """
    os.makedirs(INPUT_DIR, exist_ok=True)

    logger = logging.getLogger("fuel_scraper")
    logger.setLevel(logging.INFO)
    logger.handlers = []  # avoid duplicate handlers if re-run in same process

    fmt = logging.Formatter("%(asctime)s | %(levelname)-8s | %(message)s", datefmt="%Y-%m-%d %H:%M:%S")

    file_handler = logging.FileHandler(LOG_FILE, mode="a", encoding="utf-8")
    file_handler.setFormatter(fmt)
    logger.addHandler(file_handler)

    # Force UTF-8 on stdout where possible — Windows terminals often default
    # to a non-UTF-8 codepage (e.g. cp1252), which raises UnicodeEncodeError
    # the moment a ₹ symbol is printed. reconfigure() is safe to call even
    # if stdout is already UTF-8; wrapped in try/except for older consoles
    # that don't support reconfigure at all.
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(fmt)
    logger.addHandler(console_handler)

    return logger


log = setup_logging()


# =========================================================================
# INPUT FOLDER VALIDATION
# =========================================================================

def validate_input_folder():
    """
    Ensures Input/ exists and contains EXACTLY ONE .xlsx file.
    - If the folder is empty -> error, tell the user to place config.xlsx there.
    - If more than one .xlsx is present -> error, ambiguous which to use.
    This file is READ-ONLY as far as the script is concerned — it is never
    renamed, moved, or overwritten. It stays exactly as the user left it.
    Returns the absolute path to the file found (for logging purposes only).
    """
    os.makedirs(INPUT_DIR, exist_ok=True)

    xlsx_files = [f for f in os.listdir(INPUT_DIR) if f.lower().endswith(".xlsx") and not f.startswith("~$")]

    if len(xlsx_files) == 0:
        msg = (f"No .xlsx file found in '{INPUT_DIR}'. Please place a single "
               f"config.xlsx file inside the Input folder and re-run.")
        log.error(msg)
        raise FileNotFoundError(msg)

    if len(xlsx_files) > 1:
        msg = (f"Multiple .xlsx files found in '{INPUT_DIR}': {xlsx_files}. "
               f"Only ONE config file is allowed in the Input folder. "
               f"Please remove the extra file(s) and re-run.")
        log.error(msg)
        raise RuntimeError(msg)

    found_path = os.path.join(INPUT_DIR, xlsx_files[0])
    log.info(f"Input validation passed. Found (untouched, left as-is): {found_path}")
    return found_path


# =========================================================================
# OUTPUT FOLDER (per-day / per-run) SETUP
# =========================================================================

def setup_output_folders():
    """
    Creates:
      Output/ddmmyyyy/                 (per calendar day)
      Output/ddmmyyyy/ddmmyyyy_hhmmss/ (per run — screenshots AND the final
                                         workbook both go directly here, no
                                         extra subfolder)
    Returns (day_dir, run_dir, run_timestamp_str)
    """
    now = datetime.now()
    day_str = now.strftime("%d%m%Y")
    run_str = now.strftime("%d%m%Y_%H%M%S")

    day_dir = os.path.join(OUTPUT_DIR, day_str)
    run_dir = os.path.join(day_dir, run_str)

    os.makedirs(run_dir, exist_ok=True)
    log.info(f"Output run folder ready: {run_dir}")

    return day_dir, run_dir, run_str


# =========================================================================
# HELPERS
# =========================================================================

def clean_fuel_name(class_name):
    match = re.search(r"\bicn-(\w+)\b", class_name or "")
    if not match:
        return "Unknown"
    fuel = match.group(1)
    return {"xptwo": "XP95", "indigreen": "XtraGreen"}.get(fuel, fuel.capitalize())


def clean_price(price_str):
    """
    Extracts a float price out of a raw string like '₹101.91' or '101.91 /Ltr'.
    Returns None if nothing numeric could be found (caller then substitutes
    NO_RESPONSE so the failure is visible in the sheet rather than blank).
    """
    if not price_str:
        return None
    match = re.search(r"([\d]+\.?[\d]*)", str(price_str))
    return float(match.group(1)) if match else None


def safe_price_value(value):
    """Converts None -> 'No Response' string for writing into Excel/logs."""
    return value if value is not None else NO_RESPONSE


def format_worksheet(ws, is_igl=False):
    """
    Format headers, columns, widths, row heights, gridlines,
    and embed screenshots dynamically.
    """
    ws._images = []
    ws.sheet_view.showGridLines = True

    num_cols = len(COLS_IGL) if is_igl else len(COLS_IOCL)
    link_col = num_cols - 1
    img_col = num_cols
    price_cols = [6] if is_igl else [6, 7, 8, 9]

    header_fill = PatternFill(start_color="1F497D", end_color="1F497D", fill_type="solid")
    header_font = Font(name="Segoe UI", size=11, bold=True, color="FFFFFF")
    center_align = Alignment(horizontal="center", vertical="center")
    left_align = Alignment(horizontal="left", vertical="center")
    right_align = Alignment(horizontal="right", vertical="center")
    error_font = Font(name="Segoe UI", size=10, color="FF0000", bold=True)

    for col in range(1, num_cols + 1):
        cell = ws.cell(row=1, column=col)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = center_align

    ws.row_dimensions[1].height = 28

    for row in range(2, ws.max_row + 1):
        ws.row_dimensions[row].height = 70

        for col in range(1, num_cols + 1):
            cell = ws.cell(row=row, column=col)

            if col in price_cols:
                cell.alignment = right_align
                if isinstance(cell.value, (int, float)):
                    cell.number_format = '₹#,##0.00'
                    cell.font = Font(name="Segoe UI", size=10)
                elif cell.value == NO_RESPONSE:
                    # Flag missing/undetected prices clearly in red
                    cell.font = error_font
                else:
                    cell.font = Font(name="Segoe UI", size=10)
            elif col in [1, 2, 3, 5, link_col, img_col]:
                cell.alignment = center_align
                cell.font = Font(name="Segoe UI", size=10)
            else:
                cell.alignment = left_align
                cell.font = Font(name="Segoe UI", size=10)

        cell_link = ws.cell(row=row, column=link_col)
        rel_path = cell_link.value

        if rel_path and not str(rel_path).startswith("ERROR") and rel_path != NO_RESPONSE:
            abs_path = os.path.abspath(os.path.join(SCRIPT_DIR, rel_path)) if not os.path.isabs(rel_path) else rel_path
            if os.path.exists(abs_path):
                cell_link.hyperlink = "file://" + abs_path
                cell_link.value = "View Screenshot"
                cell_link.font = Font(name="Segoe UI", size=10, color="0563C1", underline="single")

                thumb_dir = os.path.dirname(abs_path)
                thumb_path = os.path.join(thumb_dir, f"thumb_{os.path.basename(abs_path)}")
                try:
                    with PILImage.open(abs_path) as img:
                        img.thumbnail((110, 75))
                        img.save(thumb_path)

                    xl_img = XLImage(thumb_path)
                    cell_letter = openpyxl.utils.get_column_letter(img_col)
                    ws.add_image(xl_img, f"{cell_letter}{row}")
                    ws.cell(row=row, column=img_col).value = ""
                except Exception as img_err:
                    ws.cell(row=row, column=img_col).value = f"Error: {img_err}"
                    log.warning(f"Could not embed thumbnail for row {row}: {img_err}")
            else:
                cell_link.value = "Missing Screenshot File"
                cell_link.font = error_font
        elif rel_path == NO_RESPONSE:
            cell_link.font = error_font

    from openpyxl.utils import get_column_letter
    for col in ws.columns:
        col_letter = get_column_letter(col[0].column)
        if col[0].column in [link_col, img_col]:
            ws.column_dimensions[col_letter].width = 18
        elif col[0].column == 1:
            ws.column_dimensions[col_letter].width = 25
        elif col[0].column == 5:
            ws.column_dimensions[col_letter].width = 20
        else:
            max_len = max(len(str(cell.value or '')) for cell in col)
            ws.column_dimensions[col_letter].width = max(max_len + 4, 12)


def save_workbook_data(df_iocl, df_igl):
    """
    Saves dataframe to Input/config.xlsx (single source of truth) and
    applies styling.
    """
    for col in COLS_IOCL:
        if col not in df_iocl.columns:
            df_iocl[col] = None
    df_iocl = df_iocl[COLS_IOCL]

    for col in COLS_IGL:
        if col not in df_igl.columns:
            df_igl[col] = None
    df_igl = df_igl[COLS_IGL]

    with pd.ExcelWriter(OUTPUT_EXCEL, engine='openpyxl') as writer:
        df_iocl.to_excel(writer, sheet_name="fuel prices", index=False)
        df_igl.to_excel(writer, sheet_name="igl", index=False)

    wb = openpyxl.load_workbook(OUTPUT_EXCEL)
    format_worksheet(wb["fuel prices"], is_igl=False)
    format_worksheet(wb["igl"], is_igl=True)
    wb.save(OUTPUT_EXCEL)
    log.info(f"Workbook saved: {OUTPUT_EXCEL}")


def bring_browser_window_to_os_front():
    """
    Forces the actual Chromium OS window (not just a browser tab) to the
    front of the screen, so PyAutoGUI's screenshot — which has no concept
    of Playwright tabs, only what's physically visible — captures the
    browser instead of your terminal, IDE, or any other app that currently
    holds OS-level focus.

    No-op (with a warning logged once) if pygetwindow isn't installed, or
    if no matching browser window can be found — in that case the caller
    still proceeds to screenshot whatever is currently on screen.
    """
    if not PYGETWINDOW_AVAILABLE:
        return False

    try:
        candidates = [
            w for w in gw.getAllWindows()
            if w.title and ("Chrome" in w.title or "Chromium" in w.title)
        ]
        if not candidates:
            return False

        win = candidates[0]
        if win.isMinimized:
            win.restore()
        win.activate()
        time.sleep(0.4)  # give the OS a moment to actually raise the window
        return True
    except Exception as e:
        log.warning(f"Could not activate browser window at OS level: {e}")
        return False


def take_fullscreen_screenshot(filename_prefix, page=None):
    """
    Captures a full-screen screenshot via PyAutoGUI and saves it directly
    into this run's Output/ddmmyyyy/ddmmyyyy_hhmmss/ folder.

    IMPORTANT: PyAutoGUI captures whatever is physically on screen — it has
    no idea which browser tab Playwright is working with, and Playwright's
    own page.bring_to_front() only switches the active TAB, not the OS-level
    window. If the browser window itself isn't frontmost on your desktop
    (e.g. your terminal/IDE has focus), the screenshot shows the wrong thing
    even though the correct price WAS found in the DOM. Two layers of fix
    are applied here: (1) page.bring_to_front() for the tab, (2) an OS-level
    window activation via pygetwindow for the actual window.

    Returns the relative path (from SCRIPT_DIR) on success, or NO_RESPONSE
    on failure (screenshot capture itself failed).
    """
    try:
        if page is not None:
            try:
                page.bring_to_front()
            except Exception as focus_err:
                log.warning(f"Could not bring page tab to front before screenshot: {focus_err}")

        bring_browser_window_to_os_front()

        if page is not None:
            try:
                page.wait_for_timeout(800)  # let scroll/render settle after focus
            except Exception:
                time.sleep(0.8)

        safe_name = re.sub(r'[\\/*?:"<>|]', "_", filename_prefix)
        filename = f"{safe_name}_{datetime.now().strftime('%H%M%S')}.png"
        dest_path = os.path.join(SCREENSHOTS_DIR, filename)

        screenshot = pyautogui.screenshot()
        screenshot.save(dest_path)

        rel_path = os.path.relpath(dest_path, SCRIPT_DIR)
        log.info(f"Screenshot captured: {rel_path}")
        return rel_path
    except Exception as e:
        log.error(f"Screenshot capture FAILED for '{filename_prefix}': {e}")
        return NO_RESPONSE


# =========================================================================
# PRICE EXTRACTION
#
# NOTE: The original script was truncated exactly at the point where it
# called page.goto(...) for the IOCL locator pages, so the actual selectors
# used to read Petrol/Diesel/XP95/XtraGreen off that page were never
# available to reconstruct. The selectors below are a reasonable generic
# starting point based on the icn-<fuel> class naming convention implied by
# clean_fuel_name() in the original file. VERIFY these against the live
# page (right-click a price -> Inspect) and adjust if they don't match —
# every extraction attempt is already wrapped so a wrong selector safely
# degrades to "No Response" instead of crashing the run.
# =========================================================================

def extract_iocl_prices(page, station_name):
    """
    Attempts to read Petrol / Diesel / XP95 / XtraGreen prices off an IOCL
    locator page. Returns a dict {fuel_name: price_or_None}.
    Any fuel not found on the page (station doesn't sell it, or the
    selector didn't match) comes back as None -> written as 'No Response'.
    """
    prices = {"Petrol": None, "Diesel": None, "XP95": None, "XtraGreen": None}

    try:
        page.wait_for_selector(".price-container, .fuel-price, [class*='icn-']", timeout=10000)
    except PlaywrightTimeoutError:
        log.warning(f"[{station_name}] Price container did not load in time — prices will show 'No Response'.")
        return prices

    try:
        price_blocks = page.query_selector_all("[class*='icn-']")
        for block in price_blocks:
            try:
                class_attr = block.get_attribute("class") or ""
                fuel = clean_fuel_name(class_attr)
                if fuel == "Unknown":
                    continue

                # Price text is assumed to live in a nearby sibling/parent —
                # try a few likely spots and take the first that yields a number.
                price_text = None
                parent = block.evaluate_handle("el => el.closest('.price-container, .fuel-item, div')")
                if parent:
                    price_text = parent.as_element().inner_text() if parent.as_element() else None
                if not price_text:
                    price_text = block.inner_text()

                value = clean_price(price_text)
                if value is not None and fuel in prices:
                    prices[fuel] = value
            except Exception as inner_e:
                log.warning(f"[{station_name}] Could not parse one price block: {inner_e}")
                continue
    except Exception as e:
        log.warning(f"[{station_name}] Price extraction error: {e}")

    for fuel, val in prices.items():
        if val is None:
            log.warning(f"[{station_name}] {fuel} price NOT detected -> 'No Response'.")

    return prices


def extract_igl_price(page, station_name):
    """
    Attempts to read the CNG price off the IGL prices page.
    Returns a float or None (-> 'No Response').
    """
    try:
        page.wait_for_selector("table, [class*='price']", timeout=10000)
    except PlaywrightTimeoutError:
        log.warning(f"[{station_name}] IGL price table did not load in time — 'No Response'.")
        return None

    try:
        # The IGL page lists CNG price in a table; grab the first row that
        # mentions 'Gurugram'/'Gurgaon' and pull the numeric price from it.
        rows = page.query_selector_all("table tr")
        for row in rows:
            text = row.inner_text()
            if re.search(r"gur[ug]gram|gurgaon", text, re.IGNORECASE):
                value = clean_price(text)
                if value is not None:
                    return value

        # Fallback: any element carrying a price-like class
        blocks = page.query_selector_all("[class*='price']")
        for b in blocks:
            value = clean_price(b.inner_text())
            if value is not None:
                return value

    except Exception as e:
        log.warning(f"[{station_name}] IGL price extraction error: {e}")

    log.warning(f"[{station_name}] CNG price NOT detected -> 'No Response'.")
    return None


def scroll_to_iocl_price_section(page, city_name, station_name):
    """
    Scrolls the page (up/down, wherever needed) to bring the section
    containing the fuel price into view, so the full-screen screenshot
    actually captures that content instead of whatever happened to be on
    screen at scroll position 0.

    Strategy (in priority order):
      1. Scroll straight to the actual price element (class containing
         'icn-' or 'price') — this is the MOST reliable target since it's
         the exact data already confirmed present. City name text can
         legitimately appear elsewhere on the page (breadcrumbs, page
         title, nearby-station lists) with no price near it, which was
         causing screenshots to land on the wrong section.
      2. Fall back to the city name text only if no price element is found.
      3. Fall back to a step-scroll sweep down the full page height.
    """
    try:
        price_el = page.query_selector("[class*='icn-'], [class*='price']")
        if price_el and price_el.is_visible():
            price_el.scroll_into_view_if_needed(timeout=5000)
            page.wait_for_timeout(1000)  # let scroll animation + render settle
            log.info(f"[{station_name}] Scrolled directly to price element on page.")
            return True
    except Exception as e:
        log.warning(f"[{station_name}] Could not scroll directly to price element: {e}")

    try:
        city_locator = page.get_by_text(city_name, exact=False).first
        if city_locator.count() > 0:
            city_locator.scroll_into_view_if_needed(timeout=5000)
            page.wait_for_timeout(1000)
            log.info(f"[{station_name}] Scrolled to city name '{city_name}' on page (fallback).")
            return True
    except Exception as e:
        log.warning(f"[{station_name}] Could not scroll to city name: {e}")

    # Final fallback: sweep down the full page height in steps, checking for
    # any visible price element at each stop.
    try:
        page.evaluate("window.scrollTo(0, 0)")
        page.wait_for_timeout(300)
        page_height = page.evaluate("document.body.scrollHeight")
        viewport_height = page.evaluate("window.innerHeight")
        steps = max(1, min(30, int(page_height / max(viewport_height, 1)) + 3))

        for _ in range(steps):
            price_el = page.query_selector("[class*='icn-'], [class*='price']")
            if price_el and price_el.is_visible():
                price_el.scroll_into_view_if_needed(timeout=3000)
                page.wait_for_timeout(700)
                log.info(f"[{station_name}] Scrolled to price section via full-page sweep.")
                return True
            page.mouse.wheel(0, 450)
            page.wait_for_timeout(300)
    except Exception as e:
        log.warning(f"[{station_name}] Full-page scroll sweep failed: {e}")

    log.warning(f"[{station_name}] Could not confirm scroll position for city/price section.")
    return False


def scroll_to_igl_gurugram_row(page, station_name):
    """
    Scrolls the IGL prices table (which lists many cities) up/down until the
    row matching 'Gurugram'/'Gurgaon' is found, then scrolls it into view so
    the screenshot captures that specific city + price row.
    """
    try:
        rows = page.query_selector_all("table tr")
        for row in rows:
            text = row.inner_text()
            if re.search(r"gur[ug]gram|gurgaon", text, re.IGNORECASE):
                row.scroll_into_view_if_needed(timeout=5000)
                page.wait_for_timeout(1000)
                log.info(f"[{station_name}] Scrolled to Gurugram row on IGL page.")
                return True
    except Exception as e:
        log.warning(f"[{station_name}] Could not scroll to Gurugram row: {e}")

    log.warning(f"[{station_name}] Gurugram row not found to scroll to — screenshot may not show it.")
    return False


# =========================================================================
# MODE: SCRAPE LIVE PRICES
# =========================================================================

def scrape_live_prices():
    log.info("MODE: Scraping live prices & capturing full-screen screenshots...")
    os.makedirs(PYAUTOGUI_SAVE_DIR, exist_ok=True)

    iocl_rows = []
    igl_rows = []

    with sync_playwright() as p:
        log.info("Launching Chromium browser...")
        browser = p.chromium.launch(
            headless=False,
            args=["--disable-blink-features=AutomationControlled", "--start-maximized"]
        )
        context = browser.new_context(
            no_viewport=True,
            user_agent=("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                        "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"),
            locale="en-US",
            timezone_id="Asia/Kolkata"
        )

        # ---- 1. IOCL stations ----
        for idx, s in enumerate(IOCL_STATIONS):
            if idx > 0:
                delay = random.uniform(3.0, 5.5)
                log.info(f"Waiting {delay:.2f}s to avoid rate limiting...")
                time.sleep(delay)

            log.info(f"[{idx + 1}/{len(IOCL_STATIONS)}] Loading IOCL page: {s['city']} ({s['name']})")
            page = context.new_page()
            page.set_extra_http_headers({
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.9"
            })

            now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            prices = {"Petrol": None, "Diesel": None, "XP95": None, "XtraGreen": None}
            rel_screenshot = NO_RESPONSE
            load_succeeded = False

            for attempt in range(1, 4):
                try:
                    page.goto(s["website"], timeout=30000, wait_until="domcontentloaded")
                    page.wait_for_timeout(2000)
                    load_succeeded = True
                    break
                except Exception as e:
                    log.warning(f"[{s['name']}] Attempt {attempt}/3 to load page failed: {e}")
                    time.sleep(2)

            if not load_succeeded:
                log.error(f"[{s['name']}] Page failed to load after 3 attempts. Marking all prices 'No Response'.")
            else:
                try:
                    prices = extract_iocl_prices(page, s["name"])
                except Exception as e:
                    log.error(f"[{s['name']}] Unexpected error during price extraction: {e}")

                # Only capture a screenshot if AT LEAST ONE fuel price was
                # actually detected on the page. If nothing was found, skip
                # the screenshot entirely and log it as an error instead —
                # no point saving a screenshot of a page with no prices on it.
                if any(v is not None for v in prices.values()):
                    scroll_to_iocl_price_section(page, s["city"], s["name"])
                    rel_screenshot = take_fullscreen_screenshot(f"IOCL_{s['city']}", page=page)
                else:
                    rel_screenshot = NO_RESPONSE
                    log.error(f"[{s['name']}] No fuel prices detected on page — skipping screenshot.")

            page.close()

            iocl_rows.append([
                s["website"], s["state"], s["city"], s["name"], now_str,
                safe_price_value(prices["Petrol"]),
                safe_price_value(prices["Diesel"]),
                safe_price_value(prices["XP95"]),
                safe_price_value(prices["XtraGreen"]),
                rel_screenshot, ""
            ])

        # ---- 2. IGL station(s) ----
        for idx, s in enumerate(IGL_STATIONS):
            delay = random.uniform(2.0, 4.0)
            log.info(f"Waiting {delay:.2f}s before IGL request...")
            time.sleep(delay)

            log.info(f"[{idx + 1}/{len(IGL_STATIONS)}] Loading IGL page: {s['city']} ({s['name']})")
            page = context.new_page()
            page.set_extra_http_headers({
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.9"
            })

            now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            cng_price = None
            rel_screenshot = NO_RESPONSE
            load_succeeded = False

            for attempt in range(1, 4):
                try:
                    page.goto(s["website"], timeout=30000, wait_until="domcontentloaded")
                    page.wait_for_timeout(2000)
                    load_succeeded = True
                    break
                except Exception as e:
                    log.warning(f"[{s['name']}] Attempt {attempt}/3 to load page failed: {e}")
                    time.sleep(2)

            if not load_succeeded:
                log.error(f"[{s['name']}] Page failed to load after 3 attempts. Marking CNG price 'No Response'.")
            else:
                try:
                    cng_price = extract_igl_price(page, s["name"])
                except Exception as e:
                    log.error(f"[{s['name']}] Unexpected error during price extraction: {e}")

                # Same rule as IOCL: only screenshot if a price was actually found.
                if cng_price is not None:
                    scroll_to_igl_gurugram_row(page, s["name"])
                    rel_screenshot = take_fullscreen_screenshot(f"IGL_{s['city']}", page=page)
                else:
                    rel_screenshot = NO_RESPONSE
                    log.error(f"[{s['name']}] No CNG price detected on page — skipping screenshot.")

            page.close()

            igl_rows.append([
                s["website"], s["state"], s["city"], s["name"], now_str,
                safe_price_value(cng_price), rel_screenshot, ""
            ])

        browser.close()

    df_iocl = pd.DataFrame(iocl_rows, columns=COLS_IOCL)
    df_igl = pd.DataFrame(igl_rows, columns=COLS_IGL)

    save_workbook_data(df_iocl, df_igl)
    log.info(f"Run complete. Screenshots in: {SCREENSHOTS_DIR}")
    log.info(f"Workbook: {OUTPUT_EXCEL}\n")


# =========================================================================
# MAIN
# =========================================================================

def main():
    global RUN_TIMESTAMP, DAY_OUTPUT_DIR, SCREENSHOTS_DIR, OUTPUT_EXCEL, INPUT_CONFIG_PATH

    log.info("=" * 70)
    log.info("Fuel Price Scraper — run started")

    try:
        # Validation only — this file is never renamed, moved, or written to.
        INPUT_CONFIG_PATH = validate_input_folder()
    except Exception as e:
        log.error(f"Startup validation failed: {e}")
        sys.exit(1)

    DAY_OUTPUT_DIR, SCREENSHOTS_DIR, RUN_TIMESTAMP = setup_output_folders()
    # Final workbook is named after the run timestamp itself and saved
    # directly in the run folder, alongside that run's screenshots —
    # e.g. Output/28072026/28072026_143205/28072026_143205.xlsx
    OUTPUT_EXCEL = os.path.join(SCREENSHOTS_DIR, f"{RUN_TIMESTAMP}.xlsx")

    try:
        scrape_live_prices()
    except Exception as e:
        log.error(f"Fatal error during scraping run: {e}", exc_info=True)
        sys.exit(1)

    log.info("Run finished successfully.")
    log.info("=" * 70)


if __name__ == "__main__":
    main()
